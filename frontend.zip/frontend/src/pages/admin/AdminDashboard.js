import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { adminService } from '../../services/api';
import { formatPrice } from '../../utils/currency';

function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const { selectedCurrency } = useSelector((state) => state.currency);

  useEffect(() => {
    fetchStats();
  }, [selectedCurrency]);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const res = await adminService.getAdminDashboardStats();
      setStats(res.data.stats || {});
    } catch (err) {
      console.error('Failed to fetch stats', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amazon-orange"></div>
      </div>
    );
  }

  const statCards = [
    {
      title: 'Total Revenue',
      value: formatPrice(stats?.totalRevenue || 0, selectedCurrency),
      icon: '💰',
      bgColor: 'bg-green-50',
      textColor: 'text-green-600',
    },
    {
      title: 'Active Vendors',
      value: stats?.activeVendors || 0,
      icon: '🏪',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-600',
    },
    {
      title: 'Total Products',
      value: stats?.totalProducts || 0,
      icon: '📦',
      bgColor: 'bg-purple-50',
      textColor: 'text-purple-600',
    },
    {
      title: 'Pending Orders',
      value: stats?.pendingOrders || 0,
      icon: '🛒',
      bgColor: 'bg-orange-50',
      textColor: 'text-orange-600',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Dashboard</h2>
        <p className="text-gray-600 mt-1">Welcome to your admin panel</p>
      </div>

      {/* Stat Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card, idx) => (
          <div key={idx} className={`${card.bgColor} rounded-lg p-6 shadow-sm border border-gray-200`}>
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 text-sm font-medium">{card.title}</p>
                <p className={`${card.textColor} text-3xl font-bold mt-2`}>{card.value}</p>
              </div>
              <span className="text-3xl">{card.icon}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <a
            href="/admin/vendors"
            className="p-4 bg-gradient-to-r from-amazon-blue to-amazon-light rounded-lg hover:shadow-md transition text-white font-medium"
          >
            📋 View Vendors
          </a>
          <a
            href="/admin/products"
            className="p-4 bg-gradient-to-r from-amazon-orange to-yellow-500 rounded-lg hover:shadow-md transition text-white font-medium"
          >
            📦 Manage Products
          </a>
          <a
            href="/admin/categories"
            className="p-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg hover:shadow-md transition text-white font-medium"
          >
            🏷️ Categories
          </a>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pending Vendors */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Pending Vendors</h3>
          <div className="text-center py-8 text-gray-500">
            Check the Vendors page for pending approvals
          </div>
        </div>

        {/* Low Stock Products */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Low Stock Alert</h3>
          <div className="text-center py-8 text-gray-500">
            Products with stock &lt; 10 units will appear here
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;
